# Purrfect Homes - Cat Adoption Website

A responsive website for cat adoption center built with HTML, CSS, and Bootstrap.

## Features

- Responsive design that works on all devices
- Interactive cat adoption cards with hover effects
- Modern and clean UI
- Easy deployment with Surge

## Deployment Instructions

1. Install Surge globally if you haven't already:
```bash
npm install -g surge
```

2. Deploy the website:
```bash
cd /path/to/project
surge ./
```

3. If you want to use a custom domain:
```bash
surge ./ your-domain.surge.sh
```

## Project Structure

```
.
├── index.html     # Main HTML file
├── css/           # Stylesheets
│   └── style.css  # Custom CSS
└── README.md      # This file
```

## Technologies Used

- HTML5
- CSS3
- Bootstrap 5.3.0
- Placekitten (for placeholder images)

## Browser Support

The website is compatible with all modern browsers including:
- Chrome
- Firefox
- Safari
- Edge

## License

This project is for educational purposes only.
